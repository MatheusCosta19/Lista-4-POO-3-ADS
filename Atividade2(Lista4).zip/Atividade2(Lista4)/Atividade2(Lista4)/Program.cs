﻿using System;

namespace TelaSaudacao
{
    class Program
    {
        static void Main(string[] args)
        {
            string nome = "";
            string gen = "";
            DateTime time = DateTime.Now;
            string trat = "";
            string hour = "";
            string name = "";
            

            //Nome e sobrenome
            Console.WriteLine("Digite seu nome e sobrenome: ");
            {
                try
                {

                    name = Console.ReadLine();

                }
                catch(Exception e)
                {
                    Console.Clear();
                    Console.WriteLine("Erro..." + e);
                }
            } 

            string[] separated = name.Split(' ');

            //gênero
            Console.WriteLine("Qual o seu Gênero? (m = Masculino ou f = Feminino)");
            gen = Console.ReadLine();
            gen.ToUpper();

            //horário
            Console.Clear();
            Console.WriteLine("Horário de entrada: ");
            Console.WriteLine(time.ToString("HH:mm:ss\n\n"));
          
            

            if (time.Hour > 6 && time.Hour < 12)
            {
                if (gen == "m")
                {
                    Console.WriteLine("*****Bom dia, Sr. " + separated[0] +" "+ separated[1] + "");


                }
                else
                {
                    Console.WriteLine("*****Bom dia, Sra. " + separated[0] +" "+ separated[1] +"");

                }


            }
            else if (time.Hour >= 12 && time.Hour < 18)
            {
                if (gen == "m")
                {
                    Console.WriteLine("*****Boa tarde, Sr. " + separated[0] +" "+ separated[1] + "");


                }
                else
                {
                    Console.WriteLine("*****Boa tarde, Sra. " + separated[0] +" "+ separated[1] + "");

                }

            }
            else
            {
                if (gen == "m")
                {
                    Console.WriteLine("*****Boa noite, Sr. " + separated[0] +" "+ separated[1] + "");


                }
                else
                {
                    Console.WriteLine("*****Boa noite, Sra. " + separated[0] +" "+ separated[1] + "");

                }
            }

        }
        }
    }

