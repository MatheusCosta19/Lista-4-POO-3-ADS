﻿using System;

class Bhaskara
{
    static void Main(string[] args)
    {
        int a, b, c, delta;
        double x1, x2;

        Console.WriteLine("Insira o valor para A:");
        a = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Insira o valor para B:");
        b = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Insira o valor para C:");
        c = Convert.ToInt32(Console.ReadLine());

        delta = (b * b) - 4 * (a * c);

        Console.WriteLine("Valor de Delta:" + delta);

        if (delta > 0)
        {
            x1 = (-b + Math.Sqrt(delta)) / (2 * a);
            x2 = (-b - Math.Sqrt(delta)) / (2 * a);
            Console.WriteLine("x1 = " + x1);
            Console.WriteLine("x2 = " + x2);
        }
        else if (delta == 0)
        {
            x1 = -b / (2 * a);
            Console.WriteLine("x1 = x2 = " + x1);
        }
        else
        {
            Console.WriteLine("Não existem raízes reais.");
        }
    }
}
