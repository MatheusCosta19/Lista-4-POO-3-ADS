using System;

class Program{
  public static void Main(string[] args){
    string nome;
    int a;
    float b, c, d;
    
    Console.WriteLine("Escreva o nome do funcionário: ");
    nome = Console.ReadLine();
    Console.WriteLine("Digite o número de matrícula do funcionário: ");
    a = int.Parse(Console.ReadLine());
    Console.WriteLine("Digite a quantidade de horas trabalhada no mês: ");
    b = float.Parse(Console.ReadLine());
    Console.WriteLine("Digite o valor que o funcionário recebe por hora: ");
    c = float.Parse(Console.ReadLine());
    
    d = b * c;

    Console.WriteLine("\n---Relatório---");

    Console.WriteLine("\nFuncionário: " + nome);
    Console.WriteLine("Número de matrícula do funcionário: " + a);
    Console.WriteLine("Horas trabalhadas no mês é: " + b);
    Console.WriteLine("Valor por hora: " + c);
    Console.WriteLine("Salário total: " + d);
  }
}
