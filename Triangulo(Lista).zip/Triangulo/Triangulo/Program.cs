﻿using System;

class Triangulo
{
    static void Main(string[] args)
    {
        double A, B, C;
        char escolha;
        bool incorreto;
        bool continuar = true;

        do
        {
            do
            {
                Console.WriteLine("Digite o valor de A:");
                incorreto = double.TryParse(Console.ReadLine(), out A);
                if (!incorreto)
                    Console.WriteLine("Valor inválido. Digite um número válido.");
            } while (!incorreto);

            do
            {
                Console.WriteLine("Digite o valor de B:");
                incorreto = double.TryParse(Console.ReadLine(), out B);
                if (!incorreto)
                    Console.WriteLine("Valor inválido. Digite um número válido.");
            } while (!incorreto);

            do
            {
                Console.WriteLine("Digite o valor de C:");
                incorreto = double.TryParse(Console.ReadLine(), out C);
                if (!incorreto)
                    Console.WriteLine("Valor inválido. Digite um número válido.");
            } while (!incorreto);

            Console.WriteLine("Escolha uma opção:");
            Console.WriteLine("a) Calcular a área do triângulo retângulo");
            Console.WriteLine("b) Calcular a área do círculo");
            Console.WriteLine("c) Calcular a área do trapézio");
            Console.WriteLine("d) Calcular a área do quadrado");
            Console.WriteLine("e) Calcular a área do retângulo");

            escolha = char.ToLower(Console.ReadKey().KeyChar);
            Console.WriteLine(); 

            double resultado = 0;

            switch (escolha)
            {
                case 'a':
                    resultado = (A * C) / 2;
                    break;
                case 'b':
                    resultado = Math.PI * Math.Pow(C, 2);
                    break;
                case 'c':
                    resultado = ((A + B) * C) / 2;
                    break;
                case 'd':
                    resultado = Math.Pow(B, 2);
                    break;
                case 'e':
                    resultado = A * B;
                    break;
                default:
                    Console.WriteLine("Opção inválida!");
                    break;
            }

            Console.WriteLine($"Resultado: {resultado}");

            Console.WriteLine("Deseja encerrar o programa? (S/N)");

           if (char.ToLower(Console.ReadKey().KeyChar) != 's')
            {
                continuar = false;

            }

        } while (continuar);
     }
}   
